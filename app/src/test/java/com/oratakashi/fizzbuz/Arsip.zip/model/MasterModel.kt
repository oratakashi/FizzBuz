package com.oratakashi.fizzbuz.model

abstract class MasterModel {
    abstract val members : List<Int>
}