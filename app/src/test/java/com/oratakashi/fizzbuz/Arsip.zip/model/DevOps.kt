package com.oratakashi.fizzbuz.model

data class DevOps(
    override val members : List<Int> = listOf(1, 2, 3)
)  : MasterModel()
